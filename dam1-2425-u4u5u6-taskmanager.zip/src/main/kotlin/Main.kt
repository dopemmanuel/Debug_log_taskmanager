package es.prog2425.taskmanager

import es.prog2425.taskmanager.servicios.GestorActividades

fun main() {
    GestorActividades().menu()
}